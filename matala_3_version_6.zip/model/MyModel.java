package model;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import algorithms.mazeGenerators.Maze3DSearchable;
import algorithms.mazeGenerators.Maze3d;
import algorithms.mazeGenerators.MyMaze3dGenerator;
import algorithms.search.BFS;
import algorithms.search.DFS;
import algorithms.search.Searchable;
import algorithms.search.Searcher;
import algorithms.search.Solution;
import controller.Controller;
import in.MyDecompressorInputStream;
import io.MyCompressorOutputStream;

public class MyModel extends CommonModel {

	MyMaze3dGenerator mg;
	HashMap<String,Maze3d> mazes;
	HashMap<Maze3d,Solution> solutions;
	
	public MyModel(Controller controller, int poolSize) {
		super(controller, poolSize);
		mg=new MyMaze3dGenerator();
		solutions=new HashMap<Maze3d,Solution>();
		mazes=new HashMap<String,Maze3d>();
	}

	@Override
	public void stop() {
		threadPool.shutdown();
		boolean terminated = false;
		while(!terminated)
			try {
				terminated = threadPool.awaitTermination(10, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
			}
	}

	@Override
	public void calculateFileList(String path) {
		File file = new File(path);
		
		if(!file.exists()) {
			controller.displayError("Directory not found");
			return;
		}
		
		if(!file.isDirectory()) {
			controller.displayError("Path is incorrect");
			return;
		}
		
		controller.displayFilesList(file.list());
	}

	@Override
	public void generate3DMaze(String mazeName, int length, int height, int width) {
		threadPool.execute(new Runnable(){
			@Override
			public void run(){
				Maze3d maze = mg.generate(length,height,width);
				mazes.remove(mazeName);
				mazes.put(mazeName,maze);
				controller.display3dMazeReady(mazeName);
			}
		});
	}
		
	

	@Override
	public void get3DMaze(String mazeName) {
		Maze3d maze;
		maze=mazes.get(mazeName);
		if(maze==null)
			controller.displayError("Maze "+mazeName+ " not found");
		else
		{	
			try {
				byte[]mazeAsBytes=maze.toByteArray();
				controller.display3dMaze(mazeAsBytes);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				{
					
				}
			}
		}
	}

	@Override
	public void getCrossSection(String mazeName, String axis, int index) {
		Maze3d maze;
		maze=mazes.get(mazeName);
		if(maze==null)
		{
			controller.displayError("The maze "+mazeName+ " not found");
			return;
		}
		if(index<0)
		{
			controller.displayError("The index of axis must be a not negative number");
			return;
		}
		try{
		if(axis.equals("x")&&index<maze.getLength())
		{
			controller.displayCrossSection(maze.getCrossSectionByX(index));
		}
		else
		{
			if(index>=maze.getLength())
			{
				controller.displayError("The index of X axis must be smaller than the length of the maze");
				return;
			}
		}
		if(axis.equals("y")&&index<maze.getHeight())
		{
			controller.displayCrossSection(maze.getCrossSectionByY(index));
		}
		else
		{
			if(index>=maze.getHeight())
			{
				controller.displayError("The index of Y axis must be smaller than the height of the maze");
				return;
			}
		}
		if(axis.equals("z")&&index<maze.getWidth())
		{
			controller.displayCrossSection(maze.getCrossSectionByZ(index));
		}
		else
		{
			if(index>=maze.getWidth())
			{
				controller.displayError("The index of Z axis must be smaller than the width of the maze");
				return;
			}
		}
		controller.displayError("The axis you have entered is invalid");
		return;
		}catch(Exception e){
			e.printStackTrace();
		} 
	}

	@Override
	public void saveMaze(String mazeName, String fileName) {
		Maze3d maze;
		if((maze = mazes.get(mazeName)) == null) {
			controller.displayError("Maze '" + mazeName + "' not found");
			return;
		}
		
		BufferedOutputStream bufferedMazeDecompressor;
		try {
			bufferedMazeDecompressor = new BufferedOutputStream(new MyCompressorOutputStream(new FileOutputStream(fileName)));
		} catch (FileNotFoundException e) {
			controller.displayError("File can't be open '" + fileName + "' for writing");
			return;
		}
		
		try {
			bufferedMazeDecompressor.write(maze.toByteArray());
			bufferedMazeDecompressor.flush();
		} catch (IOException e) {
			controller.displayError("Error occurred while compressing maze data");
			return;
		} finally {
			try {
				bufferedMazeDecompressor.close();
			} catch (IOException e) {
				e.printStackTrace();
				return;
			}
		}
		
		controller.display3dMazeSaved(mazeName);
	}

	@Override
	public void loadMaze(String fileName, String mazeName) {
		ByteArrayOutputStream mazeDataOut = new ByteArrayOutputStream();
		BufferedOutputStream bufferedMazeDataOut = new BufferedOutputStream(mazeDataOut);
		BufferedInputStream bufferedMazeDecompressor = null;
		try {
			bufferedMazeDecompressor = new BufferedInputStream(new MyDecompressorInputStream(new FileInputStream(fileName)));
		} catch (FileNotFoundException e) {
			controller.displayError("File can't be open '" + fileName + "' for reading");
			return;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			int b;
			while((b = bufferedMazeDecompressor.read()) != -1)
				bufferedMazeDataOut.write(b);
			bufferedMazeDataOut.flush();
		} catch (IOException e) {
			controller.displayError("Error occurred while decompressing maze data");
			return;
		} finally {
			try {
				bufferedMazeDecompressor.close();
			} catch (IOException e) {
				controller.displayError("Error occurred while closing the file");
				return;
			}
		}
		
		Maze3d maze;
		try {
			maze = new Maze3d(mazeDataOut.toByteArray());
		} catch (IOException e) {
			controller.displayError("error occurred while creating maze");
			return;
		}
		
		mazes.remove(mazeName);
		mazes.put(mazeName, maze);
		
		controller.display3dMazeLoaded(mazeName);
	}

	@Override
	public void calculateMazeSize(String mazeName) {
		Maze3d maze;
		if((maze = mazes.get(mazeName)) == null) {
			controller.displayError("Maze'" + mazeName + "' not found");
			return;
		}
		
		try {
			controller.displayMazeSize(maze.toByteArray().length);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void calculateFileSize(String fileName) {
		Maze3d maze;
		maze=mazes.get(fileName);
		if(maze==null)
		{
			controller.displayError("Maze'" + fileName + "' not found");
			return;
		}
		
		byte[] mazeAsBytes;
		try {
			mazeAsBytes = compressData(maze.toByteArray());
		} catch (IOException e) {
			return;
		}
		
		controller.displayFileSize(mazeAsBytes.length);
	}

	@Override
	public void solveMaze(String mazeName, String algorithmName) {
		Maze3d maze;
		maze=mazes.get(mazeName);
		if(maze==null)
		{
			controller.displayError("Maze'" + mazeName + "' not found");
			return;
		}
		threadPool.execute(new Runnable() {
			@Override
			public void run() {
		if(algorithmName.equals("bfs"))
		{
			solutions.put(maze,(testSearcher(new BFS(), new Maze3DSearchable(maze))));
			return;
		}
		if(algorithmName.equals("dfs"))
		{
			solutions.put(maze,testSearcher(new DFS(), new Maze3DSearchable(maze)));
			return;
		}
		controller.displayError("Algorithms you have entered is invalid");
		}});
	}
	
	@SuppressWarnings("rawtypes")
	private Solution testSearcher(Searcher searcher, Searchable searchable){
		 Solution solution=searcher.Search(searchable);
		 return solution;
	}

	@Override
	public void getSolution(String mazeName) {
		Maze3d maze;
		maze=mazes.get(mazeName);
		if(maze==null)
		{
			controller.displayError("Maze'" + mazeName + "' not found");
			return;
		}
		controller.displaySolution(solutions.get(maze));	
	}

}
