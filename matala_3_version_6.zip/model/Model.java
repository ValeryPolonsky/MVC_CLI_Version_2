package model;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * <h1> Class Model </h1>
 * The model is the main part of the calculation,
 * when the view need to do something he calls controllers and controllers 
 * call the model to do it.
 * When the model end it's activity it tells to the view through controller.
 * 
 * @author Valery Polonsky & Tomer Dricker
 *
 */
public interface Model {
	void stop();
	void calculateFileList(String path);
	void generate3DMaze(String mazeName,int length,int height,int width);
	void get3DMaze(String mazeName);
	void getCrossSection(String mazeName, String axis,int index);
	void saveMaze(String mazeName,String fileName);
	void loadMaze(String fileName,String mazeName);
	void calculateMazeSize(String mazeName);
	void calculateFileSize(String fileName);
	void solveMaze(String mazeName,String algorithmName);
	void getSolution(String mazeName);
}
