package model;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import algorithms.mazeGenerators.Maze3d;
import algorithms.mazeGenerators.Maze3dGenerator;
import algorithms.search.Solution;
import controller.Controller;
import io.MyCompressorOutputStream;

/**
 * <h1> Common Model </h1>
 * This class is abstract class for "class adapter" design pattern.
 *
 * @author Valery Polonsky & Tomer Dricker
 */
public abstract class CommonModel implements Model {
	Controller controller;
	ExecutorService threadPool;
	
	public CommonModel(Controller controller,int poolSize)
	{
		this.controller=controller;
		threadPool=Executors.newFixedThreadPool(poolSize);
	}
	
	protected byte[] compressData(byte[]data) throws IOException
	{
		ByteArrayOutputStream dataOutput=new ByteArrayOutputStream();
		MyCompressorOutputStream dataCompressor = new MyCompressorOutputStream(new BufferedOutputStream(dataOutput));
		try{
			dataCompressor.write(data);
			dataCompressor.flush();
		}catch (IOException e) {
			controller.displayError("error occurred while compressing maze data");
			throw e;
		}finally{
			try{
				dataCompressor.close();
			}catch (IOException e){
				controller.displayError("error occurred while closing the stream");
				throw e;
			}
		}
		return dataOutput.toByteArray();
	}
}
