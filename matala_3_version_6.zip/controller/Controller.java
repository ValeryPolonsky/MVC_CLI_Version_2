package controller;

import java.util.ArrayList;
import java.util.HashMap;

import algorithms.search.Solution;
import model.Model;
import view.View;

/**
 * <h1> Class Controller </h1>
 * The Controller Responsible for transferring commands between the View and the Model
 * 
 * 
 * @author Valery Polonsky & Tomer Dricker
 *
 */
public interface Controller {

	/**
	 * Stop the application
	 */
	void stop();
	/**
	 * Set the Model Fa�ade instance
	 * @param model The Model Fa�ade instance
	 */
	void setModel(Model model);
	/**
	 * Set the View Fa�ade instance
	 * @param view The View Fa�ade instance
	 */
	void setView(View view);
	/**
	 * Invoke the named command using the specified arguments
	 * @param command1 The name of the command to invoke
	 * @param args Arguments for the command
	 */
	void doCommand(String command, String[] data);
	/**
	 * Display an error message
	 * @param error The error message
	 */
	void displayError(String error);
	/**
	 * Display a list of files
	 * @param list The file list
	 */
	void displayFilesList(String[] list);
	/**
	 * Display that a 3d maze was generated
	 * @param name The name of the ready maze
	 */
	void display3dMazeReady(String name);
	/**
	 * Display a 3d maze
	 * @param mazeData The compressed maze data
	 */
	void display3dMaze(byte[] mazeData);
	/**
	 * Display a maze cross section
	 * @param crossSection The cross section data
	 */
	void displayCrossSection(int[][] crossSection);
	/**
	 * Display that a maze was saved
	 * @param name The name of the saved maze
	 */
	void display3dMazeSaved(String name);
	/**
	 * Display that a maze was loaded
	 * @param name The name of the loaded maze
	 */
	void display3dMazeLoaded(String name);
	/**
	 * Display the size of a maze
	 * @param size The size of the maze
	 */
	void displayMazeSize(int size);
	/**
	 * Display the compressed size of a maze
	 * @param length The compressed size of the maze
	 */
	void displayFileSize(int length);
	/**
	 * Display that a maze was solved
	 * @param name The name of the maze for which the solution is ready
	 */
	void displaySolutionReady(String name);
	/**
	 * Display the solution for a maze
	 * @param solution The solution
	 */
	void displaySolution(Solution solution);
}
