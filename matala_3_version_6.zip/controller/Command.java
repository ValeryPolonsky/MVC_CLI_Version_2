package controller;

import java.io.IOException;
import java.util.ArrayList;

/**
 * <h1> Class Command</h1>
 * This class will be a "parent" class of commands that will be created
 * 
* @author Valery Polonsky & Tomer Dricker
 *
 */
public interface Command {

	void doCommand(String[] data);
}
