package view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.search.Solution;
import controller.Command;

/**
 * <h1> Class View </h1>
 * display all the solutions/messages from Controller
 * 
 * 
 * 
 * @author Valery Polonsky & Tomer Dricker
 *
 */
public interface View {
	void start();
	void setCommands(HashSet<String> commands);
	void displayError(String erorMsg);
	void displayFiles(String[]listOfFiles);
	void display3DMaze(byte[]maze);
	void displayCrossSection(int[][]section);
	void displayMazeSize(int size);
	void displayFileSize(int size);
	void displaySolution(Solution solution);
	void displayMazeReady(String mazeName);
	void display3DMazeSaved(String mazeName);
	void display3DMazeLoaded(String mazeName);
	void displaySolutionReady(String mazeName);
	void displayShuttingDown();
	void displayShutDown();
}
