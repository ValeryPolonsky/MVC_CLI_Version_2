package view;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.mazeGenerators.Maze3d;
import algorithms.search.Solution;
import controller.Command;
import controller.Controller;
import in.MyDecompressorInputStream;

public class MyView extends CommonView{
    CLI cli;
    BufferedReader in;
    PrintWriter out;
    
	
	public MyView(Controller controller) {
		super(controller);
		in=new BufferedReader(new InputStreamReader(System.in));
		out=new PrintWriter(System.out);
		cli=new CLI(controller,in,out);
	}
	
	@Override
	
	public void setCommands(HashSet<String> commands)
	{
		super.setCommands(commands);
		cli.setCommands(commands);
	}
	
	@Override
	public void start() {
		cli.start();
	}

	@Override
	public void displayError(String errorMsg) {
		cli.displayLine(errorMsg);
	}

	@Override
	public void displayFiles(String[] listOfFiles) {
		for(int i=0;i<listOfFiles.length;i++)
		{
			cli.displayLine(listOfFiles[i]);
		}
	}

	@Override
	public void display3DMaze(byte[] mazeAsBytes) {
		try {
			Maze3d maze = new Maze3d(mazeAsBytes);
			for(int y=0;y<maze.getHeight();y++)
			{
				for(int x=0;x<maze.getLength();x++)
				{
					for(int z=0;z<maze.getWidth();z++)
					{
						cli.display(maze.getPointValue(x, y, z));
					}
					cli.displayLine();
				}
				cli.displayLine();
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void displayCrossSection(int[][] section) {
		for(int i=0;i<section[0].length;i++)
		{
			for(int j=0;j<section.length;j++)
			{
				cli.display(section[i][j]);
			}
			cli.displayLine("");
		}
	}

	@Override
	public void displayMazeSize(int size) {
		cli.displayLine(size);
	}

	@Override
	public void displayFileSize(int size) {
		cli.displayLine(size);
	}

	@Override
	public void displaySolution(Solution solution) {
		cli.displayLine(solution);
	}

	@Override
	public void displayMazeReady(String mazeName) {
		cli.displayLine("The maze: "+mazeName+" is ready.");
	}

	@Override
	public void display3DMazeSaved(String mazeName) {
		cli.displayLine("The maze: "+mazeName+" saved.");
	}

	@Override
	public void display3DMazeLoaded(String mazeName) {
		cli.displayLine("The maze: "+mazeName+" loaded.");
	}

	@Override
	public void displaySolutionReady(String mazeName) {
		cli.displayLine("The solution of maze: "+mazeName+" is ready.");
	}

	@Override
	public void displayShuttingDown() {
		cli.displayLine("Shutting down in process...");
	}

	@Override
	public void displayShutDown() {
		cli.displayLine("Shutting down has been completed");
	}

}
